package com.komo.nota;

import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.Charset;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout rows;
    TextView total;
    BluetoothDevice selected;
    final ArrayList<EditText[]> data = new ArrayList<>();

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        rows = findViewById(R.id.rows);
        total = findViewById(R.id.total);
        addRow();
        ((Button) findViewById(R.id.add)).setOnClickListener(v -> addRow());
        ((Button) findViewById(R.id.printer)).setOnClickListener(v -> choosePrinter());
        ((Button) findViewById(R.id.print)).setOnClickListener(v -> print());
    }

    void addRow() {
        int n = data.size() + 1;
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);

        TextView no = new TextView(this);
        no.setText("" + n);
        no.setGravity(Gravity.CENTER);
        line.addView(no, new LinearLayout.LayoutParams(45, -2));

        EditText name = new EditText(this);
        name.setHint("Nama barang");
        line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));

        // Kolom BANYAK selalu mulai dengan nilai 1
        EditText qty = new EditText(this);
        qty.setText("1");
        qty.setInputType(2);
        qty.setGravity(Gravity.CENTER);
        line.addView(qty, new LinearLayout.LayoutParams(55, -2));

        EditText price = new EditText(this);
        price.setHint("0");
        price.setInputType(2);
        price.setGravity(Gravity.RIGHT);
        line.addView(price, new LinearLayout.LayoutParams(110, -2));

        TextView lineTotal = new TextView(this);
        lineTotal.setText("0");
        lineTotal.setGravity(Gravity.RIGHT);
        line.addView(lineTotal, new LinearLayout.LayoutParams(105, -2));

        rows.addView(line);
        data.add(new EditText[]{name, qty, price});

        View.OnFocusChangeListener listener = (v, f) -> calc();
        name.setOnFocusChangeListener(listener);
        qty.setOnFocusChangeListener(listener);
        price.setOnFocusChangeListener(listener);
        android.text.TextWatcher watcher = new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence x, int st, int c, int a) {}
            public void onTextChanged(CharSequence x, int st, int b, int c) { calc(); }
            public void afterTextChanged(android.text.Editable e) {}
        };
        qty.addTextChangedListener(watcher);
        price.addTextChangedListener(watcher);
    }

    void calc() {
        long s = 0;
        for (int i = 0; i < data.size(); i++) {
            EditText[] x = data.get(i);
            long jumlah = 0;
            try {
                long q = Long.parseLong(x[1].getText().toString().trim());
                long p = Long.parseLong(x[2].getText().toString().replace(".", "").trim());
                if (q < 1) q = 1;
                jumlah = q * p;
                s += jumlah;
            } catch (Exception ignored) {}
            View line = rows.getChildAt(i);
            if (line instanceof LinearLayout && ((LinearLayout) line).getChildCount() >= 5) {
                TextView t = (TextView) ((LinearLayout) line).getChildAt(4);
                t.setText(formatRp(jumlah));
            }
        }
        total.setText("TOTAL: Rp " + formatRp(s));
    }

    String formatRp(long n) {
        return String.format(Locale.US, "%,d", n).replace(',', '.');
    }

    void choosePrinter() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_SCAN"}, 9);
            return;
        }
        BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
        if (a == null) { toast("HP tidak mendukung Bluetooth"); return; }
        if (!a.isEnabled()) { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return; }
        Set<BluetoothDevice> ds = a.getBondedDevices();
        final ArrayList<BluetoothDevice> list = new ArrayList<>(ds);
        if (list.isEmpty()) { toast("Pasangkan printer dulu di Pengaturan Bluetooth HP"); return; }
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            String nm = list.get(i).getName();
            names[i] = nm == null ? list.get(i).getAddress() : nm;
        }
        new AlertDialog.Builder(this).setTitle("Pilih Printer").setItems(names, (d, w) -> {
            selected = list.get(w);
            toast("Printer dipilih: " + names[w]);
        }).setNegativeButton("Batal", null).show();
    }

    byte[] ascii(String s) { return s.getBytes(Charset.forName("US-ASCII")); }

    String row(String no, String name, String qty, String price, String totalLine) {
        final int NAME = 15;
        name = name.replace("\n", " ");
        if (name.length() > NAME) name = name.substring(0, NAME);
        while (name.length() < NAME) name += " ";
        if (price.length() > 10) price = price.substring(price.length() - 10);
        if (totalLine.length() > 10) totalLine = totalLine.substring(totalLine.length() - 10);
        return String.format(Locale.US, "%-3s%-15s%4s%10s%10s\n", no, name, qty, price, totalLine);
    }

    void print() {
        if (selected == null) { toast("Pilih printer dulu"); return; }
        calc();
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                socket = selected.createRfcommSocketToServiceRecord(uuid);
                socket.connect();
                OutputStream out = socket.getOutputStream();
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                b.write(new byte[]{0x1B, 0x40});
                b.write(new byte[]{0x1B, 0x61, 0x01});
                b.write(new byte[]{0x1B, 0x45, 0x01});
                b.write(ascii("KOMO\n"));
                b.write(new byte[]{0x1B, 0x45, 0x00});
                b.write(ascii("Wonosari Wetan, Tamansuruh, Glagah, Bwi\nHP: 085 232 636 024\n"));
                b.write(new byte[]{0x1B, 0x61, 0x00});
                b.write(ascii("--------------------------------\n"));
                b.write(ascii("No Nama Barang     Qty     Harga       Total\n"));
                b.write(ascii("--------------------------------\n"));

                long sum = 0;
                int i = 1;
                for (EditText[] x : data) {
                    String nm = x[0].getText().toString().trim();
                    String qtyText = x[1].getText().toString().trim();
                    String pr = x[2].getText().toString().trim();
                    if (nm.length() == 0 && pr.length() == 0) continue;
                    if (qtyText.length() == 0) qtyText = "1";
                    long q = 1, p = 0;
                    try { q = Long.parseLong(qtyText); } catch (Exception ignored) {}
                    try { p = Long.parseLong(pr.replace(".", "")); } catch (Exception ignored) {}
                    if (q < 1) q = 1;
                    long jumlah = q * p;
                    b.write(ascii(row("" + i, nm, "" + q, formatRp(p), formatRp(jumlah))));
                    i++;
                    sum += jumlah;
                }

                b.write(ascii("--------------------------------\n"));
                b.write(new byte[]{0x1B, 0x45, 0x01});
                b.write(ascii("TOTAL: Rp " + formatRp(sum) + "\n"));
                b.write(new byte[]{0x1B, 0x45, 0x00});
                b.write(ascii("--------------------------------\n"));
                b.write(new byte[]{0x1B, 0x61, 0x01});
                String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
                b.write(ascii("KODE NOTA: " + stamp + "\n"));
                b.write(ascii("Terima Kasih\n\n\n"));
                b.write(new byte[]{0x1B, 0x64, 0x03});
                out.write(b.toByteArray());
                out.flush();
                Thread.sleep(300);
                socket.close();
                runOnUiThread(() -> toast("Data nota sudah dikirim ke printer"));
            } catch (Exception e) {
                try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                runOnUiThread(() -> toast("Gagal kirim ke printer: " + e.getClass().getSimpleName()));
            }
        }).start();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
