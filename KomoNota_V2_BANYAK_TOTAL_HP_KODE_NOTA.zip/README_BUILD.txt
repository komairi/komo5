KOMO NOTA - BUILD APK

1. Buka folder project ini di Android Studio.
2. Pastikan Android SDK 35 terpasang.
3. Sync Gradle.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan berada di:
   app/build/outputs/apk/debug/app-debug.apk

Atau dari terminal:
   ./gradlew assembleDebug

Catatan:
- Untuk printer Bluetooth, pasangkan printer dari Settings Bluetooth HP terlebih dahulu.
- Aplikasi memilih printer dari perangkat Bluetooth yang sudah dipasangkan.
- Printer thermal 58 mm umumnya menggunakan Bluetooth SPP.
